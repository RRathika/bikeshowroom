export const environment = {
  production: true,apiurl:"https://104.254.247.180/api/"
};
