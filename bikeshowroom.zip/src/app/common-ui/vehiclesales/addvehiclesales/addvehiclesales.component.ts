import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { data } from 'jquery';
import { ToastServiceService } from 'src/app/toast-service.service';
import { YamahaserviceService } from 'src/app/yamahaservice.service';

@Component({
  selector: 'app-addvehiclesales',
  templateUrl: './addvehiclesales.component.html',
  styleUrls: ['./addvehiclesales.component.css'],
  providers: [DatePipe]
})
export class AddvehiclesalesComponent implements OnInit {
  // permanentaddressForm:any;
  iscredit: boolean = false;
  isFinance: boolean = false;
  isCashinhand: boolean = false;
  iscard: boolean = false;
  ischeque: boolean = false;
  isUPI: boolean = false;
  isDD: boolean = false;
  isShownCash: boolean = false;
  isdisable = false;
  myDate: any;
  bookdata: any;
  username: any;
  modelname: any;
  districtname: any;
  taluk1: any;
  qualification: any;
  occupation: any;
  year: any;
  show: any;
  role: any;
  showroomname: any;
  yardname: any;
  varientcode: any;
  colorcode: any;
  modelcode: any;
  selectedObject: any;
  totaldata: any;
  finalamount: any;
  patchdata: any;
  colordetails: any;
  finance:any;
  constructor(private service: YamahaserviceService, private route: Router, private formBuilder: FormBuilder, private datePipe: DatePipe, public toastService: ToastServiceService) {
    this.myDate = this.datePipe.transform(this.myDate, 'yyyy-MM-dd');
  }
  presentaddressForm: FormGroup = this.formBuilder.group({
    doorNo: new FormControl('', [Validators.required]),
    areaName: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    district: new FormControl('', [Validators.required]),
    taluk: new FormControl('', [Validators.required]),
    pinCode: new FormControl('', [Validators.required])
  });
  permanentaddressForm: FormGroup = this.formBuilder.group({
    doorNo: new FormControl('', [Validators.required]),
    areaName: new FormControl('', [Validators.required]),
    city: new FormControl('', [Validators.required]),
    district: new FormControl('', [Validators.required]),
    taluk: new FormControl('', [Validators.required]),
    pinCode: new FormControl('', [Validators.required])
  });
  customerDetailForm: FormGroup = this.formBuilder.group({
    invoiceNo: new FormControl('', []),
    invoiceDate: new FormControl('', []),
    receiptType: new FormControl('', []),
    receiptNos: new FormControl('', []),
    date: new FormControl('', []),
    firstName: new FormControl('', []),
    lastName: new FormControl('', []),
    gender: new FormControl('', []),
    dob: new FormControl('', []),
    fatherName: new FormControl('', []),
    gstNo: new FormControl('', []),
    presentAddress: new FormControl(),
    permanentAddress: new FormControl(),
    phoneOff: new FormControl('', []),
    residence: new FormControl('', []),
    mobileNo: new FormControl('', []),
    eMail: new FormControl('', []),
    addressProof: new FormControl('', []),
    aadharNo: new FormControl('', []),
    qualification: new FormControl('', []),
    occupation: new FormControl('', []),
    maritalStatus: new FormControl('', []),
    nomineeName: new FormControl('', []),
    nomineeAge: new FormControl('', []),
    nomineeGender: new FormControl('', []),
    relation: new FormControl('', [])
  })
  vehicleDetailsForm: FormGroup = this.formBuilder.group({
    showRoomId: new FormControl('', []),
    yardId: new FormControl('', []),
    modelId: new FormControl('', []),
    chassisNo: new FormControl('', []),
    engineNo: new FormControl('', []),
    colorId: new FormControl('', []),
    keyNo: new FormControl('', []),
    month: new FormControl('', []),
    year: new FormControl('', []),
    vehicleSaleType: new FormControl('', []),
    invoiceAmount: new FormControl('', []),
    vehicleCost: new FormControl('', []),
    discountAmount: new FormControl('', []),
    tax: new FormControl('', []),
    rounded: new FormControl('', []),
    registerAt: new FormControl('', []),
    finaltotal: new FormControl('', []),
    total: new FormControl('', []),
    igst: new FormControl('', []),
    cgst: new FormControl('', []),
    sgst: new FormControl('', []),
    lifetax: new FormControl('', []),
    insurance: new FormControl('', []),
    taxtotal: new FormControl('', [])
  })
  payDetails: FormGroup = this.formBuilder.group({   
      transactionTypeId: new FormControl('', []),
      vehicleCost: new FormControl('', []),
      otherAmount: new FormControl('', []),
      totalAmount: new FormControl('', []),
      bookrecamt:new FormControl('', []),
      financeamt:new FormControl('', []),
      creditamt:new FormControl('', []),
      cashbank:new FormControl('', []),
      excessamt:new FormControl('', []),
      balanceamt:  new FormControl('', []),
      createVehicleSalePaymentDetailDTO: {
      amount: new FormControl('', []),
      currentDate: new FormControl('', []),
      cardDetails: new FormControl('', []),
      chequeDetails: new FormControl('', []),
      chequeDate: new FormControl('', []),
      chequeNo: new FormControl('', []),
      ddDetails: new FormControl('', []),
      ddDate:new FormControl('', []),
      ddNo: new FormControl('', []),
      upiNo: new FormControl('', []),
      status: new FormControl('', [])
      },
      createVehicleSaleCreditDetailDTO: {
      creditAmount: new FormControl('', []),
      name: new FormControl('', []),
      mobileNo: new FormControl('', []),
      address: new FormControl('', []),
      status: new FormControl('', [])
      },
      createVehicleSaleFinanceDetailDTO: {
      financeId: new FormControl('', []),
      downPayment: new FormControl('', []),
      status: new FormControl('', [])
      }
    })
  ngOnInit(): void {
    this.customerDetailForm.controls['receiptNos'].disable();
    this.customerDetailForm.controls['date'].disable();
    this.isdisable = true;
    this.loadadvancebook();
    this.loadname();
    this.loadmodelname();
    this.district();
    this.loadqualification();
    this.loadoccupation();
    this.getyear();
    this.show = localStorage.getItem('ShowRoomId');
    this.role = localStorage.getItem('RoleId');
    this.showroom();
    this.yard();
    this.model();
    this.color();
    this.loadfinance();
  }
  loadfinance(){
    this.service.getfinance().subscribe(data=>{
      this.finance=data;
    })
  }
  color() {
    this.service.getcolor().subscribe(data => {
      this.colordetails = data;
    })
  }
  model() {
    this.service.getbikemodel().subscribe(data => {
      this.modelcode = data;
    })
  }
  showroom() {
    this.service.getshowroom().subscribe(data => {
      this.showroomname = data;
    })
  }
  yard() {
    this.service.getyard().subscribe(data => {
      this.yardname = data;
    })
  }
  selectyard(e: any) {
    let name = e.target.value;
    this.service.showroombyyard(name).subscribe(data => {
      this.yardname = data;
    })
  }
  checkboxvalues: any = [
    {

      value: "CashInhand",
      check: 1
    },
    {

      value: "Card",
      check: 2
    },
    {

      value: "Cheque",
      check: 3

    },
    {

      value: "UPI",
      check: 4
    },
    {

      value: "DD",
      check: 5
    }
  ];
  loadqualification() {
    this.service.getqualification().subscribe(data => {
      this.qualification = data;
    })
  }
  modelnamechange(e: any) {
    let model = e.target.value;
    this.vehicleDetailsForm.patchValue({
      modelId: model
    })
    this.service.selectmodel(model).subscribe(data => {
      if (data.statusCode == 200) {
        this.colorcode = [];
        this.varientcode = [];
        this.toastService.show('Dont have related color', { classname: 'bg-danger text-light', delay: 10000 });
      }
      else {
        this.colorcode = data;
      }
    })
  }
  colornamechange(e: any) {
    let model = e.target.value;
    this.vehicleDetailsForm.patchValue({
      colorId: model
    })
    this.service.selectcolor(model).subscribe(data => {
      if (data.statusCode == 200) {
        this.varientcode = [];
        this.toastService.show('Dont have related variant', { classname: 'bg-danger text-light', delay: 10000 });
      }
      else {
        this.varientcode = data;
      }
    })
  }
  variantnamechange(e: any) {
    let variant = e.target.value;
    let show = localStorage.getItem('ShowRoomId');
    let role = localStorage.getItem('RoleId');
    this.service.vartantbydata(variant, show, role).subscribe(data => {
      this.totaldata = data;
      for (let i = 0; i <= this.totaldata.length; i++) {
        this.finalamount = Math.round(this.totaldata[i].total);
        this.totaldata[i].netamount = this.finalamount;
        console.log(this.totaldata);
      }

    })
  }
  gstcalculation(e: any) {
    debugger
    let data = e.target.value;
    let invoice = (data / 100) * (this.vehicleDetailsForm.value['vehicleCost']);
    let invoiceamount = this.vehicleDetailsForm.value['vehicleCost'] + invoice;
    let final = invoiceamount + this.vehicleDetailsForm.value['taxtotal']
    this.vehicleDetailsForm.patchValue({
      tax: invoice,
      invoiceAmount: invoiceamount,
      total: final,
      finaltotal: final
    })

  }
  applyvehicle(chass: any, cg: any, sg: any, ig: any, engine: any, ins: any, invoice: any, key: any, life: any, net: any, total: any) {
    let totalfortable = life + ins;
    //  this.patchdata=this.totaldata; 
    //  console.log(this.patchdata);
    this.vehicleDetailsForm.patchValue({
      chassisNo: chass,
      engineNo: engine,
      keyNo: key,
      vehicleCost: invoice,
      taxtotal: totalfortable,
      rounded: net,
      cgst: cg,
      sgst: sg,
      igst: ig,
      insurance: ins,
      lifetax: life
    })

  }
  loadoccupation() {
    this.service.getoccupation().subscribe(data => {
      this.occupation = data;
    })
  }
  getyear() {
    this.service.getyear().subscribe(data => {
      this.year = data;
    })
  }
  district() {
    this.service.getdistrict().subscribe(data => {
      this.districtname = data;
    })
  }
  districttaluk(e: any) {
    let name = e.target.value;
    this.service.gettaluk(name).subscribe((data: any) => {
      this.taluk1 = data
    })
  }
  loadadvancebook() {
    let bookid = localStorage.getItem('ShowRoomId')
    this.service.getadvancebook(bookid).subscribe(data => {
      this.bookdata = data;
    })
  }
  loadname() {
    this.service.getadvancename().subscribe(data => {
      this.username = data;
    })
  }
  loadmodelname() {
    this.service.getmodelname().subscribe(data => {
      this.modelname = data;
    })
  }
  apply(id: any, date1: any) {
    let date2 = date1.split('T');
    console.log(date2[0]);

    this.customerDetailForm.patchValue({ receiptNos: id, date: date2[0] });
  }
  shift() {
    this.permanentaddressForm.patchValue(this.presentaddressForm.value);
  }
  onChange(e: any) {

    if (e.value == 1) {
      this.customerDetailForm.controls['receiptNos'].enable();
      this.customerDetailForm.controls['date'].enable();
      this.isdisable = false;
    }
    else {
      this.customerDetailForm.controls['receiptNos'].disable();
      this.customerDetailForm.controls['date'].disable();
      this.isdisable = true;
    }
  }
  onKeyUp(x: any) { // appending the updated value to the variable
    let data = x.target.value;
    let final = data.replace(/\D/g, "").split(/(?:([\d]{4}))/g).filter((s: string | any[]) => s.length > 0).join("-");
    //  console.log(final);
    this.customerDetailForm.patchValue({ aadharNo: final });
  }
  submit() {
    this.customerDetailForm.patchValue({ presentAddress: this.presentaddressForm.value, permanentAddress: this.permanentaddressForm.value })
    console.log(this.customerDetailForm.value);

    // if(this.customerDetailForm.valid){
    //   this.service.savecustomerDetails(this.customerDetailForm.value).subscribe((data:any)=>{
    //   if(data.statusCode==200){      
    //     this.toastService.show(data.message, { classname: 'bg-success text-light', delay: 10000 });
    //     //this.route.navigateByUrl('/dashboard/enquirylist');
    //     }
    //     else{
    //       this.toastService.show(data.message,{classname: 'bg-danger text-light', delay: 15000});
    //     } 
    //  })    
    // }
  }
  vehicleform() {
    console.log(this.vehicleDetailsForm.value);
  }
  toggleShowCash(value: any) {
    console.log(value.target.value);
    switch (value.target.value) {
      case '1':
        this.isShownCash = !this.isShownCash;
        this.isFinance = false;
        this.iscredit = false;
        break;

      case "2":
        this.iscredit = !this.iscredit;
        this.isShownCash = false;
        this.isCashinhand = false;
        this.iscard = false;
        this.ischeque = false;
        this.isUPI = false;
        this.isDD = false;
        this.isFinance = false;
        break;
      default:
        console.log("No such day exists!");
        break;
      case "3":
        this.isFinance = !this.isFinance;
        this.isShownCash = false;
        this.isCashinhand = false;
        this.iscard = false;
        this.ischeque = false;
        this.isUPI = false;
        this.isDD = false;
        this.iscredit = false;
        break;
    }
  }

  showchecked(checked: any) {
    console.log(checked.target.value);
    let me = checked.target.value

    var x = me;
    var y: number = +x;
    console.log(y);

    switch (y) {
      case 1:
        this.isCashinhand = !this.isCashinhand;
        break;
      case 2:
        this.iscard = !this.iscard;
        break;
      case 3:
        this.ischeque = !this.ischeque;
        break;
      case 4:
        this.isUPI = !this.isUPI;
        break;
      case 5:
        this.isDD = !this.isDD;
        break; default:
        console.log("No such day exists!");
        break;
    }

  }
  finalsubmit() {
    console.log(this.payDetails.value);

  }
}
