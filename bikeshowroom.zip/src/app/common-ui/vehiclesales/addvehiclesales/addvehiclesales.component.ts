import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { YamahaserviceService } from 'src/app/yamahaservice.service';

@Component({
  selector: 'app-addvehiclesales',
  templateUrl: './addvehiclesales.component.html',
  styleUrls: ['./addvehiclesales.component.css']
})
export class AddvehiclesalesComponent implements OnInit {
  // permanentaddressForm:any;
  constructor(private service:YamahaserviceService,private route:Router,private formBuilder:FormBuilder) { }
  presentaddressForm: FormGroup = this.formBuilder.group({
    doorNo:new FormControl('',[Validators.required]),
    areaName:new FormControl('',[Validators.required]),
    city:new FormControl('',[Validators.required]),
    district:new FormControl('',[Validators.required]),
    taluk:new FormControl('',[Validators.required]),
    pinCode:new FormControl('',[Validators.required])
  });
  permanentaddressForm: FormGroup = this.formBuilder.group({
    doorNo:new FormControl('',[Validators.required]),
    areaName:new FormControl('',[Validators.required]),
    city:new FormControl('',[Validators.required]),
    district:new FormControl('',[Validators.required]),
    taluk:new FormControl('',[Validators.required]),
    pinCode:new FormControl('',[Validators.required])
  });
  customerDetailForm:FormGroup= this.formBuilder.group({
    invoiceNo:new FormControl('',[]),
    saleLetterNo: new FormControl('',[]), 
    invoiceDate: new FormControl('',[]),
    onlineInvoiceNo: new FormControl('',[]), 
    receiptType: new FormControl('',[]),
    receiptNos: new FormControl('',[]),
    date: new FormControl('',[]),
    firstName: new FormControl('',[]), 
    lastName: new FormControl('',[]), 
    gender: new FormControl('',[]),
    dob: new FormControl('',[]),
    fatherName:new FormControl('',[]),
    gstNo: new FormControl('',[]), 
    presentAddress: new FormControl(),
    permanentAddress: new FormControl(),
    phoneOff: new FormControl('',[]), 
    residence: new FormControl('',[]), 
    mobileNo: new FormControl('',[]),
    eMail: new FormControl('',[]),
    addressProof: new FormControl('',[]), 
    aadharNo: new FormControl('',[]),
    qualification: new FormControl('',[]), 
    occupation: new FormControl('',[]),
    maritalStatus: new FormControl('',[]), 
    nomineeName: new FormControl('',[]),
    nomineeAge: new FormControl('',[]),
    nomineeGender: new FormControl('',[]), 
    relation: new FormControl('',[])  
  })
  
  ngOnInit(): void {
  }
  shift(){
    this.permanentaddressForm.patchValue(this.presentaddressForm.value);
  }
  submit(){
    this.customerDetailForm.patchValue({presentAddress:this.presentaddressForm.value,permanentAddress:this.permanentaddressForm.value})
   this.service.savecustomerDetails(this.customerDetailForm.value).subscribe(data=>{
     alert(data)
   })
    
  }
}
