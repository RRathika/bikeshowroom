import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cks-top-bar-menu',
  templateUrl: './top-bar-menu.component.html',
  styleUrls: ['./top-bar-menu.component.css']
})
export class TopBarMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
